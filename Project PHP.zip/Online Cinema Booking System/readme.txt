----------------------------------------------------------------------
CinRes - Cinema Reservation
----------------------------------------------------------------------

First Linux Web server with PHP and MySQL is required.

Second The folder CinRes invite to the web server in the folder "includes" in the files and mysql.filme.php mysql.kino.php the identifier for the database type (user = root, password = 1234). Then put a link on the home page (index.php) (preferably in a popup can be opened)

Third Run the MySQL database (using phpMyAdmin?) Kino.sql the file.

4th Now manage over index_admin.php the movies.


